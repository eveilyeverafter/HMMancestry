library('testthat')
test_check('fbgenotyper')