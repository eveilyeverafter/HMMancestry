library(testthat)
suppressMessages(library(fbgenotyper))