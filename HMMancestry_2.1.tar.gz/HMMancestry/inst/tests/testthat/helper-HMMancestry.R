library(testthat)
suppressMessages(library(HMMancestry))