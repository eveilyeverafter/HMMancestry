library('testthat')
test_check('HMMancestry')